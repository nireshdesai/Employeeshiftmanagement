﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WorkPlanningService.Models
{
    public class EmployeeShiftDetail
    {
        public string EmpName { get; set; }
        public string ShiftDate { get; set; }
        public string Shifttime { get; set; }
    }
}